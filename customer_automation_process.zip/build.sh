#!/bin/bash

zip -r "customer_automation_process.zip" * -x "customer_automation_process.zip"