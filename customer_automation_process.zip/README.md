# customer_automation_process
 **Customer Automation Process** – A Robotic Process Automation (RPA) project that automates customer registration in the Challenge system and freight quotation using Correios and Jadlog APIs. The bot extracts data from a spreadsheet, retrieves CNPJ details via Brasil API, processes the registration, and generates optimized freight quotes.
